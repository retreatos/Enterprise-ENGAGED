/**
 * Example health route (Express style). If you use a different framework, adapt accordingly.
 */
import http from "http";

const server = http.createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ ok: true }));
  } else {
    res.writeHead(404);
    res.end();
  }
});

server.listen(process.env.PORT || 8080);
